﻿namespace ShoesOnContainers.Services.OrderApi 
{
    public class OrderSettings
    {
        public string ConnectionString { get; set; }
    }
}